// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * @fileoverview Code related to the popup page. Primarily calls out to the
 * background page for data on the status of the buildbots.
 */

var STATUS_LINK_BASE = 'http://70.32.156.53:10117/';

var bg = chrome.extension.getBackgroundPage();
var failuresParent = document.getElementById('bots');

if (bg.botStatusList) {
  for (var i = 0; i < bg.botStatusList.length; i++) {
    var botStatus = bg.botStatusList[i];
    if (botStatus.success)
      continue;
    var botDiv = document.createElement('div');
    botDiv.className = 'bot failure';
    botDiv.innerHTML = '<a href="' + STATUS_LINK_BASE
      + botStatus.statusLink + '" target="_blank">' + botStatus.name + '</a>';
    failuresParent.appendChild(botDiv);
  }
}