const { configBuilder } = require('pulito');
module.exports = configBuilder(__dirname);
